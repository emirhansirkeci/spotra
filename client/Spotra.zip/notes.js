// Move the logo to a div and make a hover effect
// When someone is copy something logo will be changed
// When someone is translating something logo also will be changed again

/**
 * INSTANT COPY NOTES
 */
// content js
// when someone click or shift + enter
function instantCopy() {
  chrome.runtime.sendMessage({
    action: "instantCopy",
    text: translatedText.innerText,
  });
}

spotraResult.addEventListener("click", () => {
  instantCopy();
});

// background.js

async function instantCopy(text) {
  if (!text) return;

  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });

  if (!tab) return;

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
  };

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: copyToClipboard,
    args: [text],
  });
}

// PERMISSIONS
["clipboardWrite", "scripting"];
/************* */
